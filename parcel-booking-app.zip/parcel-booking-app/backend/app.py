from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS
from geopy.distance import geodesic
import heapq
from datetime import datetime, timedelta
import pywhatkit as kit

app = Flask(__name__)

# Enable CORS for the entire app
CORS(app)

# Function to build the graph (using coordinates)
def build_graph(coordinates):
    graph = {}
    for location1, coord1 in coordinates.items():
        graph[location1] = {}
        for location2, coord2 in coordinates.items():
            if location1 != location2:
                distance = geodesic(coord1, coord2).kilometers
                graph[location1][location2] = distance
    return graph

# Dijkstra's algorithm to find the shortest path
def dijkstra(graph, start, end):
    pq = [(0, start)]  # Priority queue (distance, node)
    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    previous_nodes = {node: None for node in graph}

    while pq:
        current_distance, current_node = heapq.heappop(pq)

        if current_distance > distances[current_node]:
            continue

        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight

            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous_nodes[neighbor] = current_node
                heapq.heappush(pq, (distance, neighbor))

    # Reconstruct path
    path, current = [], end
    while previous_nodes[current] is not None:
        path.insert(0, current)
        current = previous_nodes[current]
    if path:
        path.insert(0, current)

    return path, distances[end]

# Function to send WhatsApp notifications
def notify_user(message, phone_number):
    try:
        kit.sendwhatmsg_instantly(f"+{phone_number}", message)
        print(f"Message sent: {message}")
    except Exception as e:
        print(f"Error sending message: {e}")

# Function to get available time slots for delivery
def get_available_timeslots():
    current_time = datetime.now()
    slots = []
    for i in range(1, 6):
        slot_start = current_time + timedelta(hours=i)
        slot_end = slot_start + timedelta(hours=1)
        slots.append(f"{slot_start.strftime('%Y-%m-%d %H:%M')} to {slot_end.strftime('%H:%M')}")
    return slots

# API endpoint to handle parcel booking
@app.route('/book_parcel', methods=['POST'])
def book_parcel():
    data = request.json
    user_location = data.get('location', '').lower()
    phone_number = data.get('phone_number', '')

    # Predefined locations and coordinates
    locations = {
        "hyderabad": {'BookingPoint': (16.5063, 80.6480), 'DroppingPoint': (17.385044, 78.486671)},
        "vishakapatnam": {'BookingPoint': (16.5063, 80.6480), 'DroppingPoint': (17.6869, 83.2185)},
        "kakinada": {'BookingPoint': (16.5063, 80.6480), 'DroppingPoint': (16.9894, 82.2400)}
    }

    if user_location not in locations:
        return jsonify({"error": "Parcel delivery not supported for this location."}), 400

    locations_graph = build_graph(locations[user_location])
    origin = 'BookingPoint'
    destination = 'DroppingPoint'

    # Notify the user about the parcel booking
    notify_user("Parcel booking initiated.", phone_number)

    # Find the shortest route using Dijkstra's algorithm
    route, distance = dijkstra(locations_graph, origin, destination)
    if route:
        route_details = f"Shortest route: {' -> '.join(route)} with distance: {distance:.2f} km."
        notify_user(route_details, phone_number)

        # Provide time slots
        available_slots = get_available_timeslots()
        notify_user(f"Available timeslots: {', '.join(available_slots)}", phone_number)

        return jsonify({
            "message": "Parcel booking successful.",
            "route": route_details,
            "available_slots": available_slots
        }), 200

    return jsonify({"error": "Unable to find a route for your parcel."}), 500

if __name__ == '__main__':
    app.run(debug=True)
