document.getElementById("bookParcel").addEventListener("click", async () => {
    const location = document.getElementById("location").value;
    const phone_number = document.getElementById("phone_number").value;

    if (!location || !phone_number) {
        alert("Please fill all fields.");
        return;
    }

    const response = await fetch("http://localhost:5000/book_parcel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ location, phone_number })
    });

    const result = await response.json();
    document.getElementById("result").style.display = "block";
    document.getElementById("result").innerHTML = response.ok 
        ? `<h3>${result.message}</h3><p>${result.route}</p><p>Available Slots: ${result.available_slots.join(", ")}</p>`
        : `<p>Error: ${result.error}</p>`;
});
